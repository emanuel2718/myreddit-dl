from .myredditdl import run

run()
